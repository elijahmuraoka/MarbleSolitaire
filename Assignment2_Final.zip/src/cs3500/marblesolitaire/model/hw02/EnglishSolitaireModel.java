package cs3500.marblesolitaire.model.hw02;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents an EnglishSolitaireModel and all of its supported operations.
 * This specific model supports a board with marbles placed to form a "plus-shaped design".
 * In this version, you can use a marble to jump over other marbles and remove them.
 * You typically start with 32 marbles and the game continues until either you have only a single
 * marble left (win) or you just cannot make any more moves (1).
 * It should be noted that other cultures may have different variations of this game design.
 */
public class EnglishSolitaireModel implements MarbleSolitaireModel {
  // the arm thickness, which determines the size of the board.
  private final int at;
  // the x-position of the starting empty cell.
  private final List<ArrayList<SlotState>> board;

  /**
   * empty constructor to create a standard EnglishSolitaireModel object
   * with arm thickness, row, and column values of 3.
   */
  public EnglishSolitaireModel() {
    this.at = 3;
    int center = this.getBoardSize() / 2;
    EnglishSolitaireModel duplicate = new EnglishSolitaireModel(this.at, center, center);
    this.board = duplicate.board;
  }

  /**
   * A constructor that creates an EnglishSolitaireModel object, given a value for arm thickness.
   *
   * @param at is the given arm thickness.
   * @throws IllegalArgumentException when the arm board's arm thickness is not odd or less than 3.
   */
  public EnglishSolitaireModel(int at) {
    this.at = at;
    int center = this.getBoardSize() / 2;
    EnglishSolitaireModel duplicate = new EnglishSolitaireModel(this.at, center, center);
    this.board = duplicate.board;
  }

  /**
   * A constructor which takes in a given row and column to create an EnglishSolitaireModel object.
   *
   * @param sRow is the new x-position of the empty space.
   * @param sCol is the new y-position of the empty space.
   * @throws IllegalArgumentException when placing the starting empty slot at an invalid position.
   */
  public EnglishSolitaireModel(int sRow, int sCol) throws IllegalArgumentException {
    this.at = 3;
    EnglishSolitaireModel duplicate = new EnglishSolitaireModel(this.at, sRow, sCol);
    this.board = duplicate.board;
  }

  /**
   * A constructor that takes in arm thickness, row, and column inputs to create a
   * standard EnglishSolitaireModel object.
   *
   * @param at  is the given arm thickness.
   * @param row is the row of the starting empty position
   * @param col is the column of the starting empty position
   * @throws IllegalArgumentException when the arm board's arm thickness is not odd or less than 3.
   * @throws IllegalArgumentException when placing the starting empty slot at an invalid position.
   */
  public EnglishSolitaireModel(int at, int row, int col) {
    this.at = at;
    this.board = new ArrayList<>();
    this.makeBoard(row, col);
  }

  /**
   * creates a starting game board using valid data for the user.
   *
   * @param row the row to set the starting  empty position at
   * @param col the column to set the starting empty position at
   * @throws IllegalArgumentException when the arm board's arm thickness is not odd or less than 3.
   * @throws IllegalArgumentException when placing the starting empty slot at an invalid position.
   */
  public void makeBoard(int row, int col) {
    if (!this.withinBoardDimensions(row, col)) {
      throw new IllegalArgumentException("Row and/or Column inputs are outside "
              + "this board's dimensions.");
    }
    if (this.at < 3 || this.at % 2 == 0) {
      throw new IllegalArgumentException("Arm Thickness cannot be less than 3 or an even number.");
    }
    // for each row (i)
    for (int i = 0; i < this.getBoardSize(); i++) {
      // for each column (i)
      ArrayList<SlotState> newRow = new ArrayList<>();
      for (int j = 0; j < this.getBoardSize(); j++) {
        // if (i, j) is an invalid position
        if (this.isInvalidPosition(i, j)) {
          // add an Invalid SlotState
          newRow.add(SlotState.Invalid);
        } else {
          // add a Marble SlotState
          newRow.add(SlotState.Marble);
        }
      }
      this.board.add(newRow);
    }
    // if this position is invalid
    if (board.get(row).get(col) == SlotState.Invalid) {
      // throw an exception since this position is invalid
      throw new IllegalArgumentException("Invalid empty cell position (r,c).");
    } else {
      // set this position as an Empty SlotState
      this.board.get(row).set(col, SlotState.Empty);
    }
  }

  /**
   * determines the validity of a given position.
   *
   * @param x the x-coordinate of the given slot state
   * @param y the y-coordinate of the given slot state
   * @return whether the given position is an invalid one or not
   */
  private boolean isInvalidPosition(int x, int y) {
    // boardSize
    int bs = this.getBoardSize();
    // calculates the pivot position
    int pivot = ((bs + 2) / 3) - 1;
    // is y in the y-range of invalid cells?
    boolean inYRange = (y >= 0 && y < pivot)
            || (y >= (bs - pivot) && y <= (bs - 1));
    if (x >= 0 && x < pivot) {
      return inYRange;
    }
    if (x >= (bs - pivot) && x <= (bs - 1)) {
      return inYRange;
    }
    return false;
  }

  /**
   * This operation is used to play the game by moving a marble to another location
   * by jumping over other marbles and removing the ones jumped over in the process.
   * This method MUST:
   * - Turn from slot state to empty
   * - Turn in between slot state to empty
   * - Turn to slot state to marble
   *
   * @param fromRow the row number of the position to be moved from
   *                (starts at 0)
   * @param fromCol the column number of the position to be moved from
   *                (starts at 0)
   * @param toRow   the row number of the position to be moved to
   *                (starts at 0)
   * @param toCol   the column number of the position to be moved to
   *                (starts at 0)
   * @throws IllegalArgumentException when a move is invalid, meaning...
   *                                  - the from position is not a marble
   *                                  - the to position is not empty
   *                                  - the slot position in-between is not a marble
   *                                  - the from and to positions are not exactly one slot apart
   *                                  - the from and to positions are either not in the same row
   *                                  or column
   *                                  - the from position is not within the board's dimensions
   *                                  = the to position is not within the board's dimensions
   */
  @Override
  public void move(int fromRow, int fromCol, int toRow, int toCol) throws
          IllegalArgumentException {
    if (this.canMakeMove(fromRow, fromCol, toRow, toCol)) {
      this.board.get((fromRow + toRow) / 2).set((fromCol + toCol) / 2, SlotState.Empty);
      this.board.get(fromRow).set(fromCol, SlotState.Empty);
      this.board.get(toRow).set(toCol, SlotState.Marble);
    } else {
      throw new IllegalArgumentException("The move you are trying to make is invalid.");
    }
  }

  /**
   * determine whether the user can make a valid move.
   *
   * @param fromRow the row of the from position (starting from 0)
   * @param fromCol the column of the from position (starting from 0)
   * @param toRow the row of the to position (starting from 0)
   * @param toCol the column of the to position (starting from 0)
   * @return a boolean representation of whether a user can make a move from one cell to another,
   *         meaning the two cells are on the same x or y-axis, have one marble cell in between,
   *         and the to cell is an empty one.
   */
  private boolean canMakeMove(int fromRow, int fromCol, int toRow, int toCol) {
    // initialize local variables
    boolean sameRow = (fromRow == toRow);
    boolean sameCol = (fromCol == toCol);
    boolean up = (toRow - fromRow) == -2;
    boolean down = (toRow - fromRow) == 2;
    boolean left = (toCol - fromCol) == -2;
    boolean right = (toCol - fromCol) == 2;
    boolean r = false;
    boolean c = false;
    if (sameRow) {
      r = left || right;
    }
    if (sameCol) {
      c = up || down;
    }
    // assess all conditions needed in order to make a move
    return this.withinBoardDimensions(fromRow, fromCol)
            && this.withinBoardDimensions(toRow, toCol)
            && (r || c)
            && this.getSlotAt(fromRow, fromCol) == SlotState.Marble
            && this.getSlotAt(toRow, toCol) == SlotState.Empty
            && this.getSlotAt((fromRow + toRow) / 2, (fromCol + toCol) / 2)
            == SlotState.Marble;
  }

  /**
   * checks whether a given position is within the board's dimensions.
   *
   * @param row the row of the position (x-coordinate)
   * @param col the column of the position (y-coordinate)
   * @return a boolean representation of whether the given position is within the dimensions
   *         of the board.
   */
  private boolean withinBoardDimensions(int row, int col) {
    return (row >= 0 && row < this.getBoardSize()
            && col >= 0 && col < this.getBoardSize());
  }

  @Override
  public boolean isGameOver() {
    int bs = this.getBoardSize();
    boolean result = true;
    for (int i = 0; i < bs; i++) {
      for (int j = 0; j < bs; j++) {
        SlotState current = this.getSlotAt(i, j);
        if (current == SlotState.Marble) {
          // cannot make a move to the left?
          result = result && (!this.canMakeMove(i, j, i, j + 2)
                  // cannot make a move to the right?
                  && !this.canMakeMove(i, j, i, j - 2)
                  // cannot make a move up?
                  && !this.canMakeMove(i, j, i - 2, j)
                  // cannot make a move down?
                  && !this.canMakeMove(i, j, i + 2, j));
        }
      }
    }
    return result;
  }

  @Override
  public int getBoardSize() {
    return (this.at * 3) - 2;
  }

  @Override
  public SlotState getSlotAt(int row, int col) throws IllegalArgumentException {
    if (this.withinBoardDimensions(row, col)) {
      return this.board.get(row).get(col);
    }
    throw new IllegalArgumentException("The given slot is not within this board's dimensions.");
  }

  @Override
  public int getScore() {
    int result = 0;
    for (int i = 0; i < this.getBoardSize(); i++) {
      for (int j = 0; j < this.getBoardSize(); j++) {
        SlotState current = this.getSlotAt(i, j);
        if (current == SlotState.Marble) {
          result++;
        }
      }
    }
    return result;
  }
}
