package cs3500.marblesolitaire;

import java.io.InputStreamReader;

import cs3500.marblesolitaire.controller.MarbleSolitaireController;
import cs3500.marblesolitaire.controller.MarbleSolitaireControllerImpl;
import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

/**
 * This class represents the entire Marble Solitaire Program.
 */
public class MarbleSolitaireProgram {

  /**
   * The main method for Marble Solitaire to run the program.
   *
   * @param args the user's inputs represented as an array of strings
   */
  public static void main(String[] args) {
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model);
    Readable in = new InputStreamReader(System.in);
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, in);
    controller.playGame();
  }
}
